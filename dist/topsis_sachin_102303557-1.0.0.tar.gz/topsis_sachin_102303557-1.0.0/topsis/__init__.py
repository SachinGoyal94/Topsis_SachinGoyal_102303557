# Expose the main function for `from topsis import topsis`
from .topsis import topsis

__all__ = ["topsis"]

